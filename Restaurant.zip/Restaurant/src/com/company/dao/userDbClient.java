package com.company.dao;

import com.company.models.User;

import java.sql.*;

public class userDbClient {

    public int saveUser(User user) throws Exception {
        Connection connection = null;
        try {
            connection = DbConnection.getConnection();

            String insertQuery = "Insert into User (name, sum, peopleQuantity, date, Restaurant_ID " +
                    "Values (?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(
                    insertQuery,
                    Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, user.getName());
            preparedStatement.setDouble(2,user.getSum());
            preparedStatement.setInt(3,user.getPeopleQuantity());
            preparedStatement.setString(4, user.getDate());
            preparedStatement.setInt(5,user.getRestaurant().getId());
            int affectedRows = preparedStatement.executeUpdate();
            System.out.println("Result of affected Rows " + affectedRows);
            return preparedStatement.getGeneratedKeys().getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if (connection != null) {
                connection.close();
            }
        }
    throw new Exception("Unexpected exception");
    }
}
