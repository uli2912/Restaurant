package com.company.dao;

import com.company.dao.DbConnection;
import com.company.models.Restaurant;

import java.sql.*;

public class RestaurantDbClient {


    public Restaurant saveRestaurant(Restaurant restaurant) throws Exception  {
        Connection connection = null;
        try {
            connection = DbConnection.getConnection();
            String insertSQL = "Insert into restaurant ( name, address, price, " +
                    "rating, maxQuantity)" +
                    "Values (?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertSQL, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1, restaurant.getName());
            preparedStatement.setString(2, restaurant.getAddress());
            preparedStatement.setDouble(3, restaurant.getPrice());
            preparedStatement.setDouble(4, restaurant.getRating());
            preparedStatement.setInt(5, restaurant.getMaxQuantity());
            int affectedRows = preparedStatement.executeUpdate();
            System.out.println("Affected Rows " + affectedRows);
            restaurant.setId(preparedStatement.getGeneratedKeys().getInt(1));

            return restaurant;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
        throw new Exception("Can not save to db");
    }

    public Restaurant[] getRestaurant() throws Exception {
        Connection connection = null;
        try {
            connection = DbConnection.getConnection();
            String SelectQuery = "Select * from restaurant";
            Statement statement = connection.createStatement();
            statement.executeQuery(SelectQuery);
            ResultSet resultSet = statement.executeQuery(SelectQuery);

            int countOfRestaurants = getCountOfRestaurants();

            Restaurant[] restaurants = new Restaurant[countOfRestaurants];
            int freeIndex = 0;
            while (resultSet.next()) {
            Restaurant restaurant = new Restaurant();
            restaurant.setId(resultSet.getInt("id"));
            restaurant.setName(resultSet.getString("name"));
            restaurant.setAddress(resultSet.getString(3));
            restaurant.setPrice(resultSet.getDouble(4));
            restaurant.setRating(resultSet.getDouble(5));
            restaurant.setMaxQuantity(resultSet.getInt(6));

            restaurants[freeIndex] = restaurant;
            freeIndex++;
            }
        return restaurants;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.close();
            }
        }
        throw new Exception("Sorry, but fail");
    }
    public int getCountOfRestaurants() throws Exception {
        Connection connection = null;
        try {
            connection = DbConnection.getConnection();
            String countQuery = "Select count(id) from restaurant";
            Statement statement = connection.createStatement();
            ResultSet resultSet= statement.executeQuery(countQuery);
            return resultSet.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        throw new Exception("fail");
    }

    public int deleteRestaurant(int id) throws Exception {
        Connection connection = null;
        String deleteQuery = "Delete from restaurant where id = ?";
        try {
            connection = DbConnection.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, id);
            System.out.println("Deleted");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if (connection != null) {
                connection.close();
            }
        }
        throw new Exception("Fail with deleting id " + id);
    }
    public static Restaurant getRestaurantByID(int userChosenRestaurant) throws Exception {
        Connection connection = null;

        try {
            connection = DbConnection.getConnection();
            String selectRestaurantById = "SELECT ID, name, address, rating, price, maxQuantity" +
                    "FROM Restaurant where ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(selectRestaurantById);
            preparedStatement.setInt(1, userChosenRestaurant);
            ResultSet resultSet = preparedStatement.executeQuery();
            Restaurant restaurant = new Restaurant();
            if (resultSet.next()) {
                restaurant.setId(resultSet.getInt(1));
                restaurant.setName(resultSet.getString(2));
                restaurant.setRating(resultSet.getDouble(3));
                restaurant.setPrice(resultSet.getDouble("Price"));
                restaurant.setMaxQuantity(resultSet.getInt("maxQuantity"));

            } return restaurant;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            if (connection != null) {
                connection.close();
            }
        }
        throw new Exception("Unexpected error");
    }


}