package com.company.models;

import com.company.dao.RestaurantDbClient;
import com.company.dao.userDbClient;

import java.sql.*;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
        public static void main(String[] args) throws Exception {
            User user = new User();
            userDbClient userDbClient = new userDbClient();
            System.out.println("Enter your name");
            String userName = scanner.nextLine();

            System.out.println("Enter id of restaurant");
            int userChosenRestaurant = scanner.nextInt();
            Restaurant userRestaurant = RestaurantDbClient.getRestaurantByID(userChosenRestaurant);

            System.out.println("Enter count of people");
            int countOfPeople = scanner.nextInt();

            System.out.println("Enter day between 1 and 31");
            int day = scanner.nextInt();
            double costForPeople = countOfPeople * userRestaurant.getPrice();
            user.setName(userName);
            user.setDate(day + " august");
            user.setPeopleQuantity(countOfPeople);
            user.setRestaurant(userRestaurant);
            user.setSum(costForPeople);

            int userID = userDbClient.saveUser(user);
            System.out.println("If of created user " + userID);

            System.out.println("Your sum is " + costForPeople);
    }

    public static Restaurant createRestaurant() {
        Restaurant restaurant = new Restaurant();

        printTxt("Enter name of restaurant ");
        restaurant.setName(scanner.nextLine());

        printTxt("Enter address ");
        restaurant.setAddress(scanner.nextLine());

        printTxt("Enter price ");
        restaurant.setPrice(scanner.nextDouble());

        printTxt("Enter rating ");
        restaurant.setRating(scanner.nextDouble());

        printTxt("Enter max quantity");
        restaurant.setMaxQuantity(scanner.nextInt());
        return restaurant;
    }

    private static void printTxt(String text) {
        System.out.println(text);
    }


    private static void deleteRestaurants(int id) {
        String sql = "Delete from Restaurant where id = ?";
        String url = "jdbc:sqlite:C://sqlite/Databases/restaurantService.db";
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(url);
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Success");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private static void getRestaurants() {
        String sqlQuery = "Select id, name from Restaurant";
        String url = "jdbc:sqlite:C://sqlite/Databases/restaurantService.db";
        Connection connection = null;
        try {
            try {
                connection = DriverManager.getConnection(url);
                Statement statement = connection.createStatement();

                ResultSet resultSet = statement.executeQuery(sqlQuery);
                while (resultSet.next()) {
                    System.out.println("*************");
                    System.out.println("id " + resultSet.getInt(1));
                    System.out.println("Name " + resultSet.getString(2));
                    System.out.println("*************");
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } finally {
            if (connection != null) {
                    try {
                        connection.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

        }
    }


    public static void createNewDatabase() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name of your database with .db");
        String file = scanner.nextLine();

        String url = "jdbc:sqlite:C://sqlite/Databases/" + file ;
        try {
            Connection connection = DriverManager.getConnection(url);
            if (connection != null) {
                DatabaseMetaData metaData = connection.getMetaData();
                System.out.println("The driver name is: " + metaData.getDriverName());
                System.out.println("A new database has been created");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}