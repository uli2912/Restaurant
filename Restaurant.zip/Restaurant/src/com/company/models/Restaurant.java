package com.company.models;

import java.security.PublicKey;

public class Restaurant {
    private int ID;
    private String name;
    private String address;
    private double rating;
    private double price;
    private int maxQuantity;
    public Restaurant() {

    }
    public Restaurant(int id, String name, String address, double rating, double price) {
        this.ID = id;
        this.name = name;
        this.address = address;
        this.rating = rating;
        this.price = price;
    }
    public Restaurant( String name, String address, double rating, double price) {
        this.name = name;
        this.address = address;
        this.rating = rating;
        this.price = price;
    }

    public int getId() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getRating() {
        return rating;
    }

    public int getMaxQuantity() {
        return maxQuantity;
    }

    public String getAddress() {
        return address;
    }

    public void setId(int id) {
        this.ID = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setMaxQuantity(int maxQuantity) {
        this.maxQuantity = maxQuantity;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
