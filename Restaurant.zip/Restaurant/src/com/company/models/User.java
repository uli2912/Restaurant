package com.company.models;

import java.util.Formatter;

public class User {
    private int id;
    private String name;
    private String date;
    private double sum;
    private int peopleQuantity;
    private Restaurant restaurant;
    public User() {

    }
    public User(int id, String name, String date, double sum, int peopleQuantity) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.sum= sum;
        this.peopleQuantity = peopleQuantity;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setRestaurant(Restaurant restaurant) {
        this.restaurant = restaurant;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public double getSum() {
        return sum;
    }

    public int getPeopleQuantity() {
        return peopleQuantity;
    }

    public String getDate() {
        return date;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPeopleQuantity(int peopleQuantity) {
        this.peopleQuantity = peopleQuantity;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }
}
